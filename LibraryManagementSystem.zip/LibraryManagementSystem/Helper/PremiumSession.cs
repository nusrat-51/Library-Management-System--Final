﻿namespace LibraryManagementSystem.Helper
{
    public static class PremiumSession
    {
        public const string Key = "PREMIUM_UNLOCKED";
    }
}
