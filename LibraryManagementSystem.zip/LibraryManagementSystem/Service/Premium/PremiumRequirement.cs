﻿using Microsoft.AspNetCore.Authorization;

namespace LibraryManagementSystem.Service
{
    public class PremiumRequirement : IAuthorizationRequirement { }
}
