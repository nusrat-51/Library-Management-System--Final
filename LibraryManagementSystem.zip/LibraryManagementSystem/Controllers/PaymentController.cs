﻿using LibraryManagementSystem.Data;
using LibraryManagementSystem.Models;
using LibraryManagementSystem.Service;
using LibraryManagementSystem.Helper; // ✅ needed for PremiumHandler
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using System.Security.Claims; // ✅ needed for ClaimTypes
using System.Text.Json;

namespace LibraryManagementSystem.Controllers
{
    public class PaymentController : Controller
    {
        private readonly ApplicationDbContext _context;
        private readonly IHttpClientFactory _httpClientFactory;
        private readonly IConfiguration _config;

        public PaymentController(ApplicationDbContext context, IHttpClientFactory httpClientFactory, IConfiguration config)
        {
            _context = context;
            _httpClientFactory = httpClientFactory;
            _config = config;
        }

        // ============================================================
        // FINE PAYMENT (EXISTING LOGIC - NOT DELETED)
        // ============================================================

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PayFine(int bookApplicationId, CancellationToken cancellationToken)
        {
            var app = await _context.bookApplications
                .FirstOrDefaultAsync(x => x.Id == bookApplicationId, cancellationToken);

            if (app == null) return NotFound();

            decimal finePerDay = 10;

            var today = DateTime.Today;
            var dueDate = app.ReturnDate.Date;

            decimal calculatedAmount = 0;
            if (dueDate != default && dueDate < today)
            {
                var overdueDays = (today - dueDate).Days;
                if (overdueDays > 0)
                    calculatedAmount = overdueDays * finePerDay;
            }

            decimal amount = app.FineAmount > 0 ? app.FineAmount : calculatedAmount;

            if (amount <= 0)
            {
                TempData["Error"] = "No fine due for this record.";
                return RedirectToAction("Index", "BookApplication");
            }

            var alreadyPaid = await _context.FinePayments
                .FirstOrDefaultAsync(p => p.BookApplicationId == bookApplicationId && p.Status == "Paid", cancellationToken);

            if (alreadyPaid != null)
                return RedirectToAction("Result", new { tran_id = alreadyPaid.TranId });

            var existing = await _context.FinePayments
                .FirstOrDefaultAsync(p => p.BookApplicationId == bookApplicationId && p.Status == "Initiated", cancellationToken);

            if (existing != null)
                return RedirectToAction("StartGateway", new { tranId = existing.TranId });

            var tranId = Guid.NewGuid().ToString("N");

            var payment = new FinePayment
            {
                BookApplicationId = bookApplicationId,
                StudentId = app.StudentId,
                StudentEmail = app.StudentEmail,
                Amount = amount,
                TranId = tranId,
                Status = "Initiated",
                Gateway = "SSLCommerz",
                CreatedAt = DateTime.Now
            };

            _context.FinePayments.Add(payment);
            await _context.SaveChangesAsync(cancellationToken);

            return RedirectToAction("StartGateway", new { tranId });
        }

        [Authorize]
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> PayCash(int bookApplicationId, CancellationToken cancellationToken)
        {
            var app = await _context.bookApplications
                .FirstOrDefaultAsync(x => x.Id == bookApplicationId, cancellationToken);

            if (app == null) return NotFound();

            decimal finePerDay = 10;
            var today = DateTime.Today;
            var dueDate = app.ReturnDate.Date;

            decimal calculatedAmount = 0;
            if (dueDate != default && dueDate < today)
            {
                var overdueDays = (today - dueDate).Days;
                if (overdueDays > 0)
                    calculatedAmount = overdueDays * finePerDay;
            }

            decimal amount = app.FineAmount > 0 ? app.FineAmount : calculatedAmount;

            if (amount <= 0)
            {
                TempData["Error"] = "No fine due for this record.";
                return RedirectToAction("Index", "BookApplication");
            }

            var alreadyPaid = await _context.FinePayments
                .FirstOrDefaultAsync(p => p.BookApplicationId == bookApplicationId && p.Status == "Paid", cancellationToken);

            if (alreadyPaid != null)
                return RedirectToAction("Receipt", new { tran_id = alreadyPaid.TranId });

            var tranId = Guid.NewGuid().ToString("N");

            var payment = new FinePayment
            {
                BookApplicationId = bookApplicationId,
                StudentId = app.StudentId,
                StudentEmail = app.StudentEmail,
                Amount = amount,
                TranId = tranId,
                Status = "Paid",
                Gateway = "Cash",
                ValId = "CASH",
                CreatedAt = DateTime.Now,
                PaidAt = DateTime.Now
            };

            _context.FinePayments.Add(payment);

            app.FineAmount = 0;

            await _context.SaveChangesAsync(cancellationToken);

            return RedirectToAction("Receipt", new { tran_id = tranId });
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Receipt(string tran_id, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments
                .FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);

            if (payment == null) return NotFound();

            return View("CashReceipt", payment);
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> StartGateway(string tranId, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments.FirstOrDefaultAsync(p => p.TranId == tranId, cancellationToken);
            if (payment == null) return NotFound();

            if (payment.Status == "Paid")
                return RedirectToAction("Result", new { tran_id = payment.TranId });

            var gatewayUrlOrError = await CreateSslCommerzSessionAsync(
                totalAmount: payment.Amount,
                tranId: payment.TranId,
                productName: "Library Fine Payment",
                productCategory: "Fine",
                successPath: "/Payment/Success",
                failPath: "/Payment/Fail",
                cancelPath: "/Payment/Cancel",
                ipnPath: "/Payment/Ipn",
                cancellationToken: cancellationToken
            );

            if (gatewayUrlOrError.StartsWith("ERROR::"))
                return Content(gatewayUrlOrError.Replace("ERROR::", ""));

            return Redirect(gatewayUrlOrError);
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> Success(string tran_id, string val_id, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments.FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);
            if (payment == null) return NotFound();

            payment.ValId = val_id;

            var storeId = _config["SSLCOMMERZ:StoreId"];
            var storePass = _config["SSLCOMMERZ:StorePassword"];
            var validationUrl = _config["SSLCOMMERZ:SandboxValidationUrl"];

            if (!string.IsNullOrWhiteSpace(validationUrl))
            {
                var url = $"{validationUrl}?val_id={val_id}&store_id={storeId}&store_passwd={storePass}&format=json";
                var client = _httpClientFactory.CreateClient();
                await client.GetAsync(url, cancellationToken);
            }

            payment.Status = "Paid";
            payment.PaidAt = DateTime.Now;

            var app = await _context.bookApplications.FirstOrDefaultAsync(x => x.Id == payment.BookApplicationId, cancellationToken);
            if (app != null) app.FineAmount = 0;

            await _context.SaveChangesAsync(cancellationToken);

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/Result?tran_id={tran_id}");
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> Fail(string tran_id, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments.FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);
            if (payment != null)
            {
                payment.Status = "Failed";
                await _context.SaveChangesAsync(cancellationToken);
            }

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/Result?tran_id={tran_id}");
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> Cancel(string tran_id, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments.FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);
            if (payment != null)
            {
                payment.Status = "Cancelled";
                await _context.SaveChangesAsync(cancellationToken);
            }

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/Result?tran_id={tran_id}");
        }

        [Authorize]
        [HttpGet]
        public async Task<IActionResult> Result(string tran_id, CancellationToken cancellationToken)
        {
            var payment = await _context.FinePayments.FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);
            if (payment == null) return NotFound();

            if (payment.Status == "Paid") return View("PaymentSuccess", payment);
            if (payment.Status == "Failed") return View("PaymentFailed");
            if (payment.Status == "Cancelled") return View("PaymentCancelled");

            return View("PaymentFailed");
        }

        [HttpPost]
        public IActionResult Ipn()
        {
            return Ok();
        }

        // ============================================================
        // PREMIUM MEMBERSHIP PAYMENT (NEW - ADDED, DOES NOT REMOVE ANYTHING)
        // ============================================================

        [Authorize(Roles = "Student")]
        [HttpGet]
        public async Task<IActionResult> MembershipCheckout(int days = 30, CancellationToken cancellationToken = default)
        {
            decimal amount = days switch
            {
                7 => 100m,
                15 => 200m,
                _ => 300m
            };

            var studentEmail = User?.Identity?.Name ?? "";

            // ✅ reliable way to read user id
            var sidStr = User.FindFirstValue(ClaimTypes.NameIdentifier);
            long studentId = 0;
            if (!string.IsNullOrWhiteSpace(sidStr))
                long.TryParse(sidStr, out studentId);

            if (studentId <= 0)
                return Content("StudentId not found in claims. Make sure you are logged in as Student.");

            var existingActive = await _context.PremiumMemberships
                .AsNoTracking()
                .Where(x => x.StudentId == studentId && x.Status == "Active")
                .OrderByDescending(x => x.Id)
                .FirstOrDefaultAsync(cancellationToken);

            if (existingActive != null)
            {
                // ✅ You don't have PremiumController.Membership() currently, so go back to Premium list
                return RedirectToAction("Index", "Premium");
            }

            var tranId = Guid.NewGuid().ToString("N");

            var membership = new PremiumMembership
            {
                StudentId = studentId,
                StudentEmail = studentEmail,
                Amount = amount,
                TranId = tranId,
                Status = "Initiated",
                Gateway = "SSLCommerz",
                CreatedAt = DateTime.Now,
                DurationDays = days
            };

            _context.PremiumMemberships.Add(membership);
            await _context.SaveChangesAsync(cancellationToken);

            var gatewayUrlOrError = await CreateSslCommerzSessionAsync(
                totalAmount: amount,
                tranId: tranId,
                productName: $"Premium Membership ({days} days)",
                productCategory: "Membership",
                successPath: "/Payment/MembershipSuccess",
                failPath: "/Payment/MembershipFail",
                cancelPath: "/Payment/MembershipCancel",
                ipnPath: "/Payment/Ipn",
                cancellationToken: cancellationToken
            );

            if (gatewayUrlOrError.StartsWith("ERROR::"))
                return Content(gatewayUrlOrError.Replace("ERROR::", ""));

            return Redirect(gatewayUrlOrError);
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> MembershipSuccess(string tran_id, string val_id, CancellationToken cancellationToken)
        {
            var membership = await _context.PremiumMemberships
                .FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);

            if (membership == null) return NotFound();

            membership.ValId = val_id;

            var storeId = _config["SSLCOMMERZ:StoreId"];
            var storePass = _config["SSLCOMMERZ:StorePassword"];
            var validationUrl = _config["SSLCOMMERZ:SandboxValidationUrl"];

            if (!string.IsNullOrWhiteSpace(validationUrl))
            {
                var url = $"{validationUrl}?val_id={val_id}&store_id={storeId}&store_passwd={storePass}&format=json";
                var client = _httpClientFactory.CreateClient();
                await client.GetAsync(url, cancellationToken);
            }

            membership.Status = "Active";
            membership.PaidAt = DateTime.Now;
            membership.StartDate = DateTime.Today;

            var days = membership.DurationDays <= 0 ? 30 : membership.DurationDays;
            membership.EndDate = DateTime.Today.AddDays(days);

            await _context.SaveChangesAsync(cancellationToken);

            // ✅ unlock UI instantly
            HttpContext.Session.SetString(PremiumHandler.PremiumSessionKey, "1");

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/MembershipResult?tran_id={tran_id}");
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> MembershipFail(string tran_id, CancellationToken cancellationToken)
        {
            var membership = await _context.PremiumMemberships
                .FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);

            if (membership != null)
            {
                membership.Status = "Failed";
                await _context.SaveChangesAsync(cancellationToken);
            }

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/MembershipResult?tran_id={tran_id}");
        }

        [HttpPost, HttpGet]
        public async Task<IActionResult> MembershipCancel(string tran_id, CancellationToken cancellationToken)
        {
            var membership = await _context.PremiumMemberships
                .FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);

            if (membership != null)
            {
                membership.Status = "Cancelled";
                await _context.SaveChangesAsync(cancellationToken);
            }

            var localBaseUrl = _config["SSLCOMMERZ:LocalBaseUrl"] ?? "http://localhost:5086";
            localBaseUrl = localBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            return Redirect($"{localBaseUrl}/Payment/MembershipResult?tran_id={tran_id}");
        }

        [Authorize(Roles = "Student")]
        [HttpGet]
        public async Task<IActionResult> MembershipResult(string tran_id, CancellationToken cancellationToken)
        {
            var membership = await _context.PremiumMemberships
                .FirstOrDefaultAsync(p => p.TranId == tran_id, cancellationToken);

            if (membership == null) return NotFound();

            if (membership.Status == "Active") return View("MembershipPaymentSuccess", membership);
            if (membership.Status == "Failed") return View("MembershipPaymentFailed");
            if (membership.Status == "Cancelled") return View("MembershipPaymentCancelled");

            return View("MembershipPaymentFailed");
        }

        // ============================================================
        // SHARED METHOD: CREATE SSLCommerz SESSION
        // ============================================================
        private async Task<string> CreateSslCommerzSessionAsync(
            decimal totalAmount,
            string tranId,
            string productName,
            string productCategory,
            string successPath,
            string failPath,
            string cancelPath,
            string ipnPath,
            CancellationToken cancellationToken)
        {
            var storeId = _config["SSLCOMMERZ:StoreId"];
            var storePass = _config["SSLCOMMERZ:StorePassword"];
            var sessionUrl = _config["SSLCOMMERZ:SandboxSessionUrl"];
            var currency = _config["SSLCOMMERZ:Currency"] ?? "BDT";

            var publicBaseUrl = _config["SSLCOMMERZ:PublicBaseUrl"];
            if (string.IsNullOrWhiteSpace(publicBaseUrl))
                return "ERROR::PublicBaseUrl missing in appsettings.json (SSLCOMMERZ:PublicBaseUrl)";

            publicBaseUrl = publicBaseUrl.Split("->")[0].Trim().TrimEnd('/');

            var successUrl = $"{publicBaseUrl}{successPath}";
            var failUrl = $"{publicBaseUrl}{failPath}";
            var cancelUrl = $"{publicBaseUrl}{cancelPath}";
            var ipnUrl = $"{publicBaseUrl}{ipnPath}";

            var email = User?.Identity?.Name ?? "student@library.com";

            var postData = new Dictionary<string, string>
            {
                ["store_id"] = storeId ?? "",
                ["store_passwd"] = storePass ?? "",
                ["total_amount"] = totalAmount.ToString("0.00"),
                ["currency"] = currency,
                ["tran_id"] = tranId,

                ["success_url"] = successUrl,
                ["fail_url"] = failUrl,
                ["cancel_url"] = cancelUrl,
                ["ipn_url"] = ipnUrl,

                ["cus_name"] = email,
                ["cus_email"] = email,
                ["cus_add1"] = "Dhaka",
                ["cus_city"] = "Dhaka",
                ["cus_country"] = "Bangladesh",
                ["cus_phone"] = "01700000000",

                ["shipping_method"] = "NO",
                ["product_name"] = productName,
                ["product_category"] = productCategory,
                ["product_profile"] = "general"
            };

            if (string.IsNullOrWhiteSpace(sessionUrl) || !Uri.IsWellFormedUriString(sessionUrl, UriKind.Absolute))
                return "ERROR::Session URL invalid. Check SSLCOMMERZ:SandboxSessionUrl in appsettings.json";

            var client = _httpClientFactory.CreateClient();
            var response = await client.PostAsync(sessionUrl, new FormUrlEncodedContent(postData), cancellationToken);
            var json = await response.Content.ReadAsStringAsync(cancellationToken);

            if (!response.IsSuccessStatusCode)
                return $"ERROR::SSLCOMMERZ HTTP ERROR: {(int)response.StatusCode}\n\n{json}";

            using var doc = JsonDocument.Parse(json);

            if (!doc.RootElement.TryGetProperty("GatewayPageURL", out var gatewayUrlEl))
                return "ERROR::SSLCOMMERZ session failed: " + json;

            var gatewayUrl = gatewayUrlEl.GetString();
            if (string.IsNullOrWhiteSpace(gatewayUrl))
                return "ERROR::SSLCOMMERZ GatewayPageURL missing: " + json;

            return gatewayUrl;
        }
    }
}
