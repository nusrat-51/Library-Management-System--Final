﻿using LibraryManagementSystem.Data;
using LibraryManagementSystem.Helper;
using LibraryManagementSystem.Service;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Http;
using Microsoft.EntityFrameworkCore;

namespace LibraryManagementSystem.Controllers
{
    [Authorize(Roles = "Student")]
    public class PremiumController : Controller
    {
        private readonly IPremiumAccessService _premiumService;
        private readonly ISignInHelper _signInHelper;
        private readonly ApplicationDbContext _context;

        // ✅ keep same key name as BookApplicationController uses
        private const string StudentCardSessionKey = "StudentIdCardNo";

        // ✅ New: separate key for storing barcode (so we don't mix "student card no" with "barcode")
        private const string PremiumBarcodeSessionKey = "PremiumBarcode";

        public PremiumController(
            IPremiumAccessService premiumService,
            ISignInHelper signInHelper,
            ApplicationDbContext context)
        {
            _premiumService = premiumService;
            _signInHelper = signInHelper;
            _context = context;
        }

        // ✅ Premium Collection page: everyone can SEE, only unlocked can APPLY
        [HttpGet]
        public async Task<IActionResult> Index(CancellationToken ct)
        {
            var premiumBooks = await _context.Books
                .AsNoTracking()
                .Where(b => b.IsPremium)
                .OrderByDescending(b => b.Id)
                .ToListAsync(ct);

            ViewData["Title"] = "Premium Collection";
            ViewData["ActivePage"] = "Premium";

            var studentId = _signInHelper.UserId ?? 0;
            bool canApplyPremium = false;

            if (studentId > 0)
            {
                // ✅ session unlock
                var unlocked = HttpContext.Session.GetString(PremiumHandler.PremiumSessionKey) == "1";

                // ✅ DB purchased membership unlock
                var purchased = await _premiumService.HasPurchasedMembershipAsync(studentId, ct);

                canApplyPremium = unlocked || purchased;

                // ✅ If purchased but session key not set, keep UI consistent (optional but helpful)
                if (purchased && !unlocked)
                {
                    HttpContext.Session.SetString(PremiumHandler.PremiumSessionKey, "1");
                }
            }

            ViewBag.CanApplyPremium = canApplyPremium;

            return View(premiumBooks);
        }

        // ✅ NEW: Premium Membership purchase page (student will buy online)
        // This does NOT remove barcode unlock. It is an additional feature.
        [HttpGet]
        public async Task<IActionResult> Membership(CancellationToken ct)
        {
            ViewData["Title"] = "Premium Membership";
            ViewData["ActivePage"] = "PremiumMembership";

            var studentId = _signInHelper.UserId ?? 0;
            if (studentId <= 0) return Forbid();

            // Optional: show membership status in UI
            var hasMembership = await _premiumService.HasPurchasedMembershipAsync(studentId, ct);
            ViewBag.HasMembership = hasMembership;

            return View();
        }

        // ✅ NEW: Student clicks buy -> we redirect to PaymentController flow
        // NOTE: This only redirects. Actual SSLCommerz logic stays in PaymentController.
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult BuyMembership(int days = 30)
        {
            var studentId = _signInHelper.UserId ?? 0;
            if (studentId <= 0) return Forbid();

            // ✅ Redirect to your PaymentController method for membership checkout
            // You will create/ensure this action exists in PaymentController:
            // PaymentController.MembershipCheckout(int days)
            return RedirectToAction("MembershipCheckout", "Payment", new { days });
        }

        [HttpGet]
        public IActionResult Unlock()
        {
            ViewData["Title"] = "Unlock Premium";
            ViewData["ActivePage"] = "Premium";
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> Unlock(string barcode, CancellationToken ct)
        {
            var studentId = _signInHelper.UserId ?? 0;
            if (studentId <= 0) return Forbid();

            if (string.IsNullOrWhiteSpace(barcode))
            {
                TempData["Error"] = "Please enter your barcode.";
                return RedirectToAction(nameof(Unlock));
            }

            var ok = await _premiumService.ValidateBarcodeAsync(studentId, barcode, ct);
            if (!ok)
            {
                TempData["Error"] = "Invalid barcode. Please try again.";
                return RedirectToAction(nameof(Unlock));
            }

            // ✅ set session unlock (IMPORTANT)
            HttpContext.Session.SetString(PremiumHandler.PremiumSessionKey, "1");

            // ✅ Keep your existing logic (don't delete):
            // You used barcode in StudentCardSessionKey to avoid null for BookApplication.
            // We'll keep it BUT also store barcode separately (better clarity).
            HttpContext.Session.SetString(StudentCardSessionKey, barcode.Trim());
            HttpContext.Session.SetString(PremiumBarcodeSessionKey, barcode.Trim());

            TempData["Success"] = "Premium section unlocked successfully!";
            return RedirectToAction(nameof(Index));
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult Lock()
        {
            // ✅ remove both
            HttpContext.Session.Remove(PremiumHandler.PremiumSessionKey);
            HttpContext.Session.Remove(StudentCardSessionKey);
            HttpContext.Session.Remove(PremiumBarcodeSessionKey);

            TempData["Success"] = "Premium section locked.";
            return RedirectToAction(nameof(Unlock));
        }
    }
}
